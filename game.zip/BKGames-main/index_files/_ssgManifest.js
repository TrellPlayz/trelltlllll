self.__SSG_MANIFEST = new Set([
    "\u002Fpost\u002Fcategory\u002Fbig-paintball",
    "\u002Fpost\u002Fcategory\u002Fbuild-and-survive",
    "\u002Fpost\u002Fcategory\u002Fmy-restaurant",
    "\u002Fpost\u002Fcategory\u002Fother",
    "\u002Fpost\u002Fcategory\u002Fpet-simulator-1",
    "\u002Fpost\u002Fcategory\u002Fpet-simulator-2",
    "\u002Fpost\u002Fcategory\u002Fpet-simulator-x",
    "\u002Fpost",
    "\u002F",
    "\u002Fpost\u002F[id]",
]);
self.__SSG_MANIFEST_CB && self.__SSG_MANIFEST_CB();
