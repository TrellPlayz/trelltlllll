"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [409],
    {
        9409: function (e, t, r) {
            r.d(t, {
                qP: function () {
                    return Ye;
                },
                Fx: function () {
                    return Qe;
                },
                E7: function () {
                    return $;
                },
                lj: function () {
                    return Me;
                },
                f5: function () {
                    return be;
                },
                if: function () {
                    return je;
                },
                pR: function () {
                    return Re;
                },
                EP: function () {
                    return Ce;
                },
                PH: function () {
                    return g;
                },
                gG: function () {
                    return se;
                },
                I1: function () {
                    return Je;
                },
                Ik: function () {
                    return De;
                },
                uW: function () {
                    return j;
                },
                pV: function () {
                    return b;
                },
                cx: function () {
                    return s;
                },
                $_: function () {
                    return ke;
                },
                qt: function () {
                    return Ie;
                },
                o_: function () {
                    return Te;
                },
                h4: function () {
                    return A;
                },
                yo: function () {
                    return K;
                },
                j0: function () {
                    return k;
                },
                W_: function () {
                    return U;
                },
                cT: function () {
                    return q;
                },
                U8: function () {
                    return ze;
                },
                l2: function () {
                    return de;
                },
                uh: function () {
                    return xe;
                },
                Ag: function () {
                    return oe;
                },
                Ke: function () {
                    return me;
                },
                aN: function () {
                    return z;
                },
                UV: function () {
                    return rt;
                },
            });
            var n = r(7294),
                l = r(4184),
                a = r.n(l);
            r(3935);
            function i(e, t, r) {
                return t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : (e[t] = r), e;
            }
            function o(e, t) {
                if (null == e) return {};
                var r,
                    n,
                    l = (function (e, t) {
                        if (null == e) return {};
                        var r,
                            n,
                            l = {},
                            a = Object.keys(e);
                        for (n = 0; n < a.length; n++) (r = a[n]), t.indexOf(r) >= 0 || (l[r] = e[r]);
                        return l;
                    })(e, t);
                if (Object.getOwnPropertySymbols) {
                    var a = Object.getOwnPropertySymbols(e);
                    for (n = 0; n < a.length; n++) (r = a[n]), t.indexOf(r) >= 0 || (Object.prototype.propertyIsEnumerable.call(e, r) && (l[r] = e[r]));
                }
                return l;
            }
            function s(e) {
                var t = e.children,
                    r = o(e, ["children"]);
                return (0, n.createElement)(
                    "p",
                    (function (e) {
                        for (var t = 1; t < arguments.length; t++) {
                            var r = null != arguments[t] ? arguments[t] : {},
                                n = Object.keys(r);
                            "function" === typeof Object.getOwnPropertySymbols &&
                                (n = n.concat(
                                    Object.getOwnPropertySymbols(r).filter(function (e) {
                                        return Object.getOwnPropertyDescriptor(r, e).enumerable;
                                    })
                                )),
                                n.forEach(function (t) {
                                    i(e, t, r[t]);
                                });
                        }
                        return e;
                    })({}, r),
                    t
                );
            }
            var c = r(5893),
                u = r(5675);
            function f(e, t, r) {
                return t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : (e[t] = r), e;
            }
            function d(e, t) {
                if (null == e) return {};
                var r,
                    n,
                    l = (function (e, t) {
                        if (null == e) return {};
                        var r,
                            n,
                            l = {},
                            a = Object.keys(e);
                        for (n = 0; n < a.length; n++) (r = a[n]), t.indexOf(r) >= 0 || (l[r] = e[r]);
                        return l;
                    })(e, t);
                if (Object.getOwnPropertySymbols) {
                    var a = Object.getOwnPropertySymbols(e);
                    for (n = 0; n < a.length; n++) (r = a[n]), t.indexOf(r) >= 0 || (Object.prototype.propertyIsEnumerable.call(e, r) && (l[r] = e[r]));
                }
                return l;
            }
            function g(e) {
                var t = e.img,
                    r = e.wrapperStyle,
                    n = e.brownM,
                    l = e.greenM,
                    i = e.blurStyle,
                    o = d(e, ["img", "wrapperStyle", "brownM", "greenM", "blurStyle"]),
                    s = a()(f({ "relative flex items-center": !0 }, "".concat(r), !0)),
                    g = a()(f({ "absolute left-4 bottom-4  sm:bottom-4 sm:left-4 sm:bottom-4 lg:left-3 lg:bottom-14": n, "absolute left-8 bottom-4 sm:left-10 sm:bottom-4 lg:left-16 lg:bottom-9": l }, "".concat(i), !0));
                return (0, c.jsxs)(
                    "div",
                    (function (e) {
                        for (var t = 1; t < arguments.length; t++) {
                            var r = null != arguments[t] ? arguments[t] : {},
                                n = Object.keys(r);
                            "function" === typeof Object.getOwnPropertySymbols &&
                                (n = n.concat(
                                    Object.getOwnPropertySymbols(r).filter(function (e) {
                                        return Object.getOwnPropertyDescriptor(r, e).enumerable;
                                    })
                                )),
                                n.forEach(function (t) {
                                    f(e, t, r[t]);
                                });
                        }
                        return e;
                    })({ className: s }, o, { children: [(0, c.jsx)("div", { className: g }), (0, c.jsx)(u.default, { priority: !0, src: t, alt: "", layout: "fill" })] })
                );
            }
            var m = r(3578),
                p = r(1217);
            function x(e, t, r) {
                return t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : (e[t] = r), e;
            }
            function h() {
                return (
                    (h =
                        Object.assign ||
                        function (e) {
                            for (var t = 1; t < arguments.length; t++) {
                                var r = arguments[t];
                                for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
                            }
                            return e;
                        }),
                    h.apply(this, arguments)
                );
            }
            var b = (0, p.Pi)(function (e) {
                var t = h({}, e),
                    r = (0, m.oR)().state,
                    l = (0, n.useState)(0),
                    a = l[0],
                    i = l[1],
                    o = (0, n.useState)(0),
                    s = o[0],
                    u = o[1],
                    f = (0, n.useState)(0),
                    d = f[0],
                    g = f[1],
                    p = (0, n.useState)(0),
                    b = p[0],
                    y = p[1],
                    v = (0, n.useState)(!1),
                    w = v[0],
                    O = v[1],
                    S = (0, n.useMemo)(
                        function () {
                            return (e = r.counterDate), new Date(e).getTime();
                            var e;
                        },
                        [r.counterDate]
                    );
                return (
                    (0, n.useEffect)(
                        function () {
                            var e;
                            return (
                                w ||
                                    (e = setInterval(function () {
                                        var e = S - new Date().getTime();
                                        if (e >= 0) {
                                            var t = Math.floor(e / 864e5),
                                                r = Math.floor((e % 864e5) / 36e5),
                                                n = Math.floor((e % 36e5) / 6e4),
                                                l = Math.floor((e % 6e4) / 1e3);
                                            i(t), u(r), g(n), y(l);
                                        } else O(!0), i("0"), u("0"), g("0"), y("0");
                                    }, 1e3)),
                                function () {
                                    return clearInterval(e);
                                }
                            );
                        },
                        [a, s, d, b, w, S]
                    ),
                    (0, c.jsxs)(
                        "div",
                        (function (e) {
                            for (var t = 1; t < arguments.length; t++) {
                                var r = null != arguments[t] ? arguments[t] : {},
                                    n = Object.keys(r);
                                "function" === typeof Object.getOwnPropertySymbols &&
                                    (n = n.concat(
                                        Object.getOwnPropertySymbols(r).filter(function (e) {
                                            return Object.getOwnPropertyDescriptor(r, e).enumerable;
                                        })
                                    )),
                                    n.forEach(function (t) {
                                        x(e, t, r[t]);
                                    });
                            }
                            return e;
                        })({}, t, {
                            children: [
                                (0, c.jsx)(j, { isDisabled: w || a <= 0, time: a >= 10 ? a : "0".concat(a), category: "DAYS" }),
                                (0, c.jsx)(j, { isDisabled: w || s <= 0, time: s >= 10 ? s : "0".concat(s), category: "HOURS" }),
                                (0, c.jsx)(j, { isDisabled: w, time: d >= 10 ? d : "0".concat(d), category: "MINUTES" }),
                                (0, c.jsx)(j, { isDisabled: w, time: b >= 10 ? b : "0".concat(b), category: "SECONDS" }),
                                w
                                    ? (0, c.jsx)("p", {
                                          className:
                                              "absolute top-14 whitespace-nowrap text-center border-4 border-white bg-counterRed text-white px-4 py-4 rounded-full font-bold text-xl left-[50%] lg:left-[45%] transform-gpu translate-x-[-50%] translate-y-[-50%]",
                                          children: r.counterEndText,
                                      })
                                    : null,
                            ],
                        })
                    )
                );
            });
            function y(e, t, r) {
                return t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : (e[t] = r), e;
            }
            function v(e, t) {
                if (null == e) return {};
                var r,
                    n,
                    l = (function (e, t) {
                        if (null == e) return {};
                        var r,
                            n,
                            l = {},
                            a = Object.keys(e);
                        for (n = 0; n < a.length; n++) (r = a[n]), t.indexOf(r) >= 0 || (l[r] = e[r]);
                        return l;
                    })(e, t);
                if (Object.getOwnPropertySymbols) {
                    var a = Object.getOwnPropertySymbols(e);
                    for (n = 0; n < a.length; n++) (r = a[n]), t.indexOf(r) >= 0 || (Object.prototype.propertyIsEnumerable.call(e, r) && (l[r] = e[r]));
                }
                return l;
            }
            var j = (0, n.memo)(function (e) {
                    var t = e.time,
                        r = e.isDisabled,
                        n = e.category,
                        l = v(e, ["time", "isDisabled", "category"]),
                        i = a()({ "rounded-xl h-[78px] w-full sm:max-w-max100 sm:max-h-max100 flex flex-col items-center justify-center": !0, "bg-white": !r, "bg-timeDone/10": r }),
                        o = a()({ "font-extrabold text-4xl": !0, "opacity-50": r });
                    return (0, c.jsxs)(
                        "div",
                        (function (e) {
                            for (var t = 1; t < arguments.length; t++) {
                                var r = null != arguments[t] ? arguments[t] : {},
                                    n = Object.keys(r);
                                "function" === typeof Object.getOwnPropertySymbols &&
                                    (n = n.concat(
                                        Object.getOwnPropertySymbols(r).filter(function (e) {
                                            return Object.getOwnPropertyDescriptor(r, e).enumerable;
                                        })
                                    )),
                                    n.forEach(function (t) {
                                        y(e, t, r[t]);
                                    });
                            }
                            return e;
                        })({ className: i }, l, { children: [(0, c.jsx)("p", { className: o, children: t }), (0, c.jsx)("p", { className: "text-heroTextGrey text-xs font-semibold", children: n })] })
                    );
                }),
                w = r(1664);
            function O(e, t, r) {
                return t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : (e[t] = r), e;
            }
            function S(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {},
                        n = Object.keys(r);
                    "function" === typeof Object.getOwnPropertySymbols &&
                        (n = n.concat(
                            Object.getOwnPropertySymbols(r).filter(function (e) {
                                return Object.getOwnPropertyDescriptor(r, e).enumerable;
                            })
                        )),
                        n.forEach(function (t) {
                            O(e, t, r[t]);
                        });
                }
                return e;
            }
            function N(e, t) {
                if (null == e) return {};
                var r,
                    n,
                    l = (function (e, t) {
                        if (null == e) return {};
                        var r,
                            n,
                            l = {},
                            a = Object.keys(e);
                        for (n = 0; n < a.length; n++) (r = a[n]), t.indexOf(r) >= 0 || (l[r] = e[r]);
                        return l;
                    })(e, t);
                if (Object.getOwnPropertySymbols) {
                    var a = Object.getOwnPropertySymbols(e);
                    for (n = 0; n < a.length; n++) (r = a[n]), t.indexOf(r) >= 0 || (Object.prototype.propertyIsEnumerable.call(e, r) && (l[r] = e[r]));
                }
                return l;
            }
            function k(e) {
                var t = e.width,
                    r = void 0 === t ? 20 : t,
                    n = e.height,
                    l = void 0 === n ? 20 : n,
                    a = e.href,
                    i = e.linkTxt,
                    o = e.src,
                    s = e.withLink,
                    f = void 0 === s || s,
                    d = N(e, ["width", "height", "href", "linkTxt", "src", "withLink"]);
                return (0, c.jsx)(c.Fragment, {
                    children: f
                        ? (0, c.jsx)(w.default, {
                              href: a,
                              passHref: !0,
                              children: (0, c.jsxs)("div", S({}, d, { children: [(0, c.jsx)(u.default, { alt: "icon", width: r, height: l, src: "./_next/static/media/bag.a179b4b7.svg" }), (0, c.jsx)("a", { className: "", children: i })] })),
                          })
                        : (0, c.jsxs)("div", S({}, d, { children: [(0, c.jsx)(u.default, { alt: "icon", width: r, height: l, src: "./_next/static/media/arrow.69d54574.svg" }), (0, c.jsx)("p", { children: i })] })),
                });
            }
            var P = r(1472);
            function B(e, t, r) {
                return t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : (e[t] = r), e;
            }
            function I(e, t) {
                if (null == e) return {};
                var r,
                    n,
                    l = (function (e, t) {
                        if (null == e) return {};
                        var r,
                            n,
                            l = {},
                            a = Object.keys(e);
                        for (n = 0; n < a.length; n++) (r = a[n]), t.indexOf(r) >= 0 || (l[r] = e[r]);
                        return l;
                    })(e, t);
                if (Object.getOwnPropertySymbols) {
                    var a = Object.getOwnPropertySymbols(e);
                    for (n = 0; n < a.length; n++) (r = a[n]), t.indexOf(r) >= 0 || (Object.prototype.propertyIsEnumerable.call(e, r) && (l[r] = e[r]));
                }
                return l;
            }
            function A(e) {
                var t = e.title,
                    r = e.description,
                    n = e.titleStyle,
                    l = e.descriptionStyle,
                    a = e.directionStart,
                    i = void 0 === a ? "translateY(-30px)" : a,
                    o = e.directionEnd,
                    s = void 0 === o ? "translateY(0px)" : o,
                    u = e.children,
                    f = e.state,
                    d = void 0 === f || f,
                    g = I(e, ["title", "description", "titleStyle", "descriptionStyle", "directionStart", "directionEnd", "children", "state"]),
                    m = (0, P.useSpring)({ config: P.config.wobbly, transform: d ? s : i, opacity: d ? "1" : "0", delay: 200 });
                return (0, c.jsxs)(
                    P.a.header,
                    (function (e) {
                        for (var t = 1; t < arguments.length; t++) {
                            var r = null != arguments[t] ? arguments[t] : {},
                                n = Object.keys(r);
                            "function" === typeof Object.getOwnPropertySymbols &&
                                (n = n.concat(
                                    Object.getOwnPropertySymbols(r).filter(function (e) {
                                        return Object.getOwnPropertyDescriptor(r, e).enumerable;
                                    })
                                )),
                                n.forEach(function (t) {
                                    B(e, t, r[t]);
                                });
                        }
                        return e;
                    })({}, g, { style: m, children: [(0, c.jsx)("h2", { className: n, children: t }), u, (0, c.jsx)("p", { className: l, children: r })] })
                );
            }
            var E = { src: "./_next/static/media/twitter.c1a489e1.svg", height: 26, width: 32 },
                T = { src: "./_next/static/media/yt.cd1802ae.svg", height: 24, width: 35 },
                D = { src: "./_next/static/media/discord.763c98ce.svg", height: 24, width: 32 };
            function M(e, t, r) {
                return t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : (e[t] = r), e;
            }
            function G() {
                return (
                    (G =
                        Object.assign ||
                        function (e) {
                            for (var t = 1; t < arguments.length; t++) {
                                var r = arguments[t];
                                for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
                            }
                            return e;
                        }),
                    G.apply(this, arguments)
                );
            }
            function z(e) {
                var t = G({}, e);
                return (0, c.jsxs)(
                    "div",
                    (function (e) {
                        for (var t = 1; t < arguments.length; t++) {
                            var r = null != arguments[t] ? arguments[t] : {},
                                n = Object.keys(r);
                            "function" === typeof Object.getOwnPropertySymbols &&
                                (n = n.concat(
                                    Object.getOwnPropertySymbols(r).filter(function (e) {
                                        return Object.getOwnPropertyDescriptor(r, e).enumerable;
                                    })
                                )),
                                n.forEach(function (t) {
                                    M(e, t, r[t]);
                                });
                        }
                        return e;
                    })({}, t, {
                        children: [
                            (0, c.jsx)(w.default, {
                                href: "https://discord.com/invite/bkgames",
                                passHref: !0,
                                children: (0, c.jsx)("a", {
                                    target: "_blank",
                                    rel: "noopener noreferrer",
                                    className: "flex items-center sidebarSocialBtn shadow-glowBlue bg-discord cursor-pointer",
                                    children: (0, c.jsx)(u.default, { src: D, alt: "discord" }),
                                }),
                            }),
                            (0, c.jsx)(w.default, {
                                href: "https://twitter.com/BKOfficialTeam",
                                passHref: !0,
                                children: (0, c.jsx)("a", {
                                    target: "_blank",
                                    rel: "noopener noreferrer",
                                    className: "flex items-center sidebarSocialBtn shadow-glowLightBlue bg-twitter cursor-pointer",
                                    children: (0, c.jsx)(u.default, { src: E, alt: "twitter" }),
                                }),
                            }),
                            (0, c.jsx)(w.default, {
                                href: "https://www.youtube.com/@BKProsYT/featured",
                                passHref: !0,
                                children: (0, c.jsx)("a", {
                                    target: "_blank",
                                    rel: "noopener noreferrer",
                                    className: "flex items-center sidebarSocialBtn shadow-glowRed bg-yt cursor-pointer",
                                    children: (0, c.jsx)(u.default, { src: T, alt: "yt" }),
                                }),
                            }),
                        ],
                    })
                );
            }
            var R = { src: "/_next/static/media/plus.9d60f3d3.svg", height: 18, width: 17 };
            function _(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
                return n;
            }
            function C(e, t) {
                return (
                    (function (e) {
                        if (Array.isArray(e)) return e;
                    })(e) ||
                    (function (e, t) {
                        var r = null == e ? null : ("undefined" !== typeof Symbol && e[Symbol.iterator]) || e["@@iterator"];
                        if (null != r) {
                            var n,
                                l,
                                a = [],
                                i = !0,
                                o = !1;
                            try {
                                for (r = r.call(e); !(i = (n = r.next()).done) && (a.push(n.value), !t || a.length !== t); i = !0);
                            } catch (s) {
                                (o = !0), (l = s);
                            } finally {
                                try {
                                    i || null == r.return || r.return();
                                } finally {
                                    if (o) throw l;
                                }
                            }
                            return a;
                        }
                    })(e, t) ||
                    (function (e, t) {
                        if (!e) return;
                        if ("string" === typeof e) return _(e, t);
                        var r = Object.prototype.toString.call(e).slice(8, -1);
                        "Object" === r && e.constructor && (r = e.constructor.name);
                        if ("Map" === r || "Set" === r) return Array.from(r);
                        if ("Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return _(e, t);
                    })(e, t) ||
                    (function () {
                        throw new TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
                    })()
                );
            }
            var Y = function () {
                    var e = (0, n.useRef)(null),
                        t = (0, n.useState)(void 0),
                        r = t[0],
                        l = t[1],
                        a = (0, n.useCallback)(function () {
                            var t;
                            null === (t = e.current) || void 0 === t || t.disconnect();
                        }, []),
                        i = (0, n.useCallback)(function () {
                            (e.current = new ResizeObserver(
                                (function (e, t) {
                                    var r;
                                    return function () {
                                        for (var n = arguments.length, l = new Array(n), a = 0; a < n; a++) l[a] = arguments[a];
                                        var i = this;
                                        clearTimeout(r),
                                            (r = window.setTimeout(function () {
                                                e.apply(i, l);
                                            }, t));
                                    };
                                })(function (e) {
                                    var t = C(e, 1)[0];
                                    return l(function () {
                                        return t.contentRect.width;
                                    });
                                }, 500)
                            )),
                                e.current.observe(window.document.body);
                        }, []);
                    return (
                        (0, n.useEffect)(
                            function () {
                                return (
                                    i(),
                                    function () {
                                        return a();
                                    }
                                );
                            },
                            [i, a]
                        ),
                        r
                    );
                },
                H = { src: "https://raw.githubusercontent.com/DxrkSvde/BKGames/main/_next/static/media/imgSliderArrowLeft.b72fdc16.svg", height: 94, width: 94 },
                L = { src: "./_next/static/media/imgSliderArrowRight.e631e21d.svg", height: 94, width: 94 };
            var W = { src: "./_next/static/media/arrow.69d54574.svg", height: 18, width: 27 },
                V = r(6037);
            function F(e, t, r) {
                return t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : (e[t] = r), e;
            }
            function X(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {},
                        n = Object.keys(r);
                    "function" === typeof Object.getOwnPropertySymbols &&
                        (n = n.concat(
                            Object.getOwnPropertySymbols(r).filter(function (e) {
                                return Object.getOwnPropertyDescriptor(r, e).enumerable;
                            })
                        )),
                        n.forEach(function (t) {
                            F(e, t, r[t]);
                        });
                }
                return e;
            }
            function U() {
                var e = function () {
                        d(function (e) {
                            return e + i;
                        }),
                            b.current++;
                    },
                    t = function () {
                        d(function (e) {
                            return e - i;
                        }),
                            b.current--;
                    },
                    r = (0, m.oR)().state,
                    l = Y(),
                    a = (0, n.useState)(0),
                    i = a[0],
                    o = a[1],
                    s = (0, n.useState)(0),
                    f = s[0],
                    d = s[1],
                    g = (0, n.useRef)(null),
                    p = (0, n.useRef)(r.imgObj.length),
                    x = (0, n.useRef)(""),
                    h = (0, n.useRef)(!1),
                    b = (0, n.useRef)(0),
                    y = (0, P.useSpring)({ config: P.config.gentle, transform: "translateX(".concat(f, "%)"), boxShadow: "0px 0px 35px -16px rgba(54, 70, 76, 1)" }),
                    v = (0, P.useSpring)({ config: P.config.gentle, transform: "translateX(".concat(f, "%)"), opacity: 0.5 });
                (0, n.useEffect)(function () {
                    window.innerWidth <= 766 && (d(-Math.abs((7 / g.current.offsetWidth) * 180)), (b.current = 0)), window.innerWidth >= 766 && (d(0), (b.current = 1));
                }, []),
                    (0, n.useEffect)(
                        function () {
                            l <= 766 && -1 !== b.current && o(-(Math.abs((7 / g.current.offsetWidth) * 100) + 100)),
                                l <= 766 && b.current > 0 && b.current === p.current && (d(-Math.abs((7 / g.current.offsetWidth) * 180)), (b.current = 0), (h.current = !0)),
                                l <= 766 && -1 === b.current && (d(-Math.abs((7 / g.current.offsetWidth) * 6 * 100 + 501.5)), (b.current = r.imgObj.length - 1), (h.current = !0)),
                                l > 766 && o(-(Math.abs((7 / g.current.offsetWidth) * 100) + 100)),
                                l >= 766 && b.current > 0 && b.current === p.current && (d(100), (b.current = 0), (h.current = !0)),
                                l >= 766 && -1 === b.current && (d(-400), (b.current = r.imgObj.length - 1), (h.current = !0));
                        },
                        [l, f, r.imgObj.length]
                    );
                var j = (0, V.useSwipeable)({
                    onSwipedLeft: function () {
                        e();
                    },
                    onSwipedRight: function () {
                        t();
                    },
                });
                return (0, c.jsxs)("div", {
                    className: "relative overflow-x-hidden ",
                    children: [
                        (0, c.jsx)("div", {
                            className: "absolute top-[50%] left-[50%] transform-gpu translate-x-[-50%] translate-y-[-50%] z-[90]",
                            children: (0, c.jsxs)("div", {
                                className: "w-screen justify-around px-20 hidden md:flex",
                                children: [
                                    (0, c.jsx)("div", { onClick: t, className: "cursor-pointer", children: (0, c.jsx)(u.default, { src: H, alt: "arrow_left", width: 80, height: 80 }) }),
                                    (0, c.jsx)("div", { onClick: e, className: "cursor-pointer", children: (0, c.jsx)(u.default, { src: L, alt: "arrow_right", width: 80, height: 80 }) }),
                                ],
                            }),
                        }),
                        (0, c.jsx)(
                            "div",
                            X({ className: "overflow-x-hidden relative w-[calc(100%*6)] md:w-[calc(33%*6)] flex justify-center gap-2 snap-x snap-mandatory p-5" }, j, {
                                children: r.imgObj.map(function (e, t) {
                                    return b.current === t
                                        ? ((x.current = e.link), (0, c.jsx)(q, { ref: g, spring: y, imgSrc: e.image, name: e.name, description: e.type, href: "".concat(e.link) }, e.name))
                                        : (0, c.jsx)(q, { ref: g, spring: v, imgSrc: e.image, name: e.name, description: e.type, href: "".concat(e.link) }, e.name);
                                }),
                            })
                        ),
                        (0, c.jsx)("div", {
                            className: "flex justify-center mt-4 mb-3 py-2",
                            children: (0, c.jsx)(k, { className: "roundButtonClass flex flex-row-reverse bg-pageBlue shadow-glowBlue", src: W, href: x.current, linkTxt: "View on Roblox" }),
                        }),
                    ],
                });
            }
            var q = (0, n.forwardRef)(function (e, t) {
                return (0,
                c.jsx)(P.a.div, { ref: t, style: e.spring, className: "h-full w-full md:w-1/3 relative p-5 rounded-3xl bg-white/90", children: (0, c.jsx)(w.default, { href: e.href, passHref: !0, children: (0, c.jsxs)("a", { target: "_blank", rel: "noopener noreferrer", children: [(0, c.jsx)("div", { className: "relative aspect-video overflow-hidden rounded-3xl", children: (0, c.jsx)(u.default, { src: e.imgSrc, alt: "", layout: "responsive", width: 454, height: 272.4 }) }), (0, c.jsx)(A, { className: "flex flex-col items-center mt-5 mb-1", title: e.name, description: e.description, titleStyle: "text-pageBlack font-bold text-xl lg:text-size26", descriptionStyle: "bg-pageOrange tracking-wider text-white font-bold px-3 py-1 rounded-full mt-2" })] }) }) });
            });
            function $(e) {
                var t = e.frontpage,
                    r = e.blogMain,
                    n = e.blogItem,
                    l = e.blogImgSrc,
                    i = e.ratioImg,
                    o = a()({ "py-2": t || r, "relative overflow-hidden rounded-blog": t || r || n }),
                    s = a()({ "w-1/2 h-3/5 rounded-blog overflow-hidden relative": t || r, "w-1/2 h-3/4 rounded-blog overflow-hidden relative": n });
                return (0, c.jsxs)("div", {
                    className: o,
                    children: [
                        (0, c.jsx)("div", { className: "blur-md relative ", children: (0, c.jsx)(u.default, { src: "%2Fthumbnail_gameicon.png", alt: "", width: 454, height: 454 * i }) }),
                        (0, c.jsx)("div", {
                            className: "absolute top-0 w-full h-full flex justify-center items-center",
                            children: (0, c.jsx)("div", { className: s, children: (0, c.jsx)(u.default, { src: "%2Fthumbnail_gameicon.png", alt: "", width: 227, height: 227 }) }),
                        }),
                    ],
                });
            }
            var Q = { src: "/_next/static/media/bag.a179b4b7.svg", height: 18, width: 18 };
            function K(e) {
                var t = e.frontImages,
                    r = (0, m.oR)().state,
                    l = (0, n.useState)(!1),
                    i = l[0],
                    o = l[1];
                (0, n.useEffect)(function () {
                    var e = setTimeout(function () {
                        o(!0);
                    }, 1e3);
                    return function () {
                        return clearTimeout(e);
                    };
                }, []);
                var s = a()({
                    "p-4 lg:px-8 flex justify-center lg:justify-start gap-3 my-4 lg:my-1 relative sm:gap-4": !0,
                    "transform transition-all translate-y-3 opacity-0 delay-300": !i,
                    "transform transition-all translate-y-0 opacity-1": i,
                });
                return (0, c.jsxs)("div", {
                    className: "bg-heroBannerBG relative w-full lg:flex flex-row-reverse justify-center lg:h-[85vh] lg:max-w-7xl lg:gap-4 xl:gap-8 m-auto",
                    children: [
                        t
                            ? (0, c.jsxs)("div", {
                                  className: "lg:flex lg:h-[85vh] lg:overflow-y-hidden",
                                  children: [
                                      (0, c.jsxs)("div", {
                                          className: "flex lg:flex-col lg:transform-gpu lg:translate-y-8 justify-center gap-8 lg:gap-24 py-10 sm:py-16 max-w-[540px] mx-auto",
                                          children: [
                                              (0, c.jsxs)(rt, {
                                                  state: i,
                                                  start: "translateY(20px)",
                                                  end: "translateY(0px)",
                                                  className: "blur2imagesWrapper",
                                                  children: [
                                                      (0, c.jsx)(g, { brownM: !0, wrapperStyle: "blurImageItemWrapper", blurStyle: "blurImageItemBlur", img: t.image2 }),
                                                      (0, c.jsx)(g, { greenM: !0, wrapperStyle: "blurImageItemWrapper", blurStyle: "blurImageItemBlur", img: t.image1 }),
                                                  ],
                                              }),
                                              (0, c.jsxs)(rt, {
                                                  state: i,
                                                  start: "translateY(20px)",
                                                  end: "translateY(0px)",
                                                  className: "hidden md:flex blur2imagesWrapper",
                                                  children: [
                                                      (0, c.jsx)(g, { brownM: !0, wrapperStyle: "blurImageItemWrapper", blurStyle: "blurImageItemBlur", img: t.image2 }),
                                                      (0, c.jsx)(g, { greenM: !0, wrapperStyle: "blurImageItemWrapper", blurStyle: "blurImageItemBlur", img: t.image1 }),
                                                  ],
                                              }),
                                          ],
                                      }),
                                      (0, c.jsxs)("div", {
                                          className: "hidden lg:flex lg:flex-col lg:transform-gpu lg:-translate-y-8 justify-center gap-8 sm:gap-24 py-10 sm:py-16",
                                          children: [
                                              (0, c.jsxs)(rt, {
                                                  state: i,
                                                  start: "translateY(-20px)",
                                                  end: "translateY(0px)",
                                                  className: "blur2imagesWrapper",
                                                  children: [
                                                      (0, c.jsx)(g, { greenM: !0, wrapperStyle: "blurImageItemWrapper", blurStyle: "blurImageItemBlur", img: t.image1 }),
                                                      (0, c.jsx)(g, { brownM: !0, wrapperStyle: "blurImageItemWrapper", blurStyle: "blurImageItemBlur", img: t.image2 }),
                                                  ],
                                              }),
                                              (0, c.jsxs)(rt, {
                                                  state: i,
                                                  start: "translateY(-20px)",
                                                  end: "translateY(0px)",
                                                  className: "blur2imagesWrapper",
                                                  children: [
                                                      (0, c.jsx)(g, { greenM: !0, wrapperStyle: "blurImageItemWrapper", blurStyle: "blurImageItemBlur", img: t.image1 }),
                                                      (0, c.jsx)(g, { brownM: !0, wrapperStyle: "blurImageItemWrapper", blurStyle: "blurImageItemBlur", img: t.image2 }),
                                                  ],
                                              }),
                                          ],
                                      }),
                                  ],
                              })
                            : null,
                        (0, c.jsxs)("div", {
                            className: "flex flex-col h-full justify-center lg:gap-4 pb-4",
                            children: [
                                (0, c.jsx)(rt, {
                                    state: i,
                                    className: "",
                                    children: (0, c.jsx)(A, {
                                        className: "leading-12 lg:leading-tight",
                                        title: r.heroTitleDesc.title,
                                        description: r.heroTitleDesc.description,
                                        titleStyle: "title text-size50 lg:text-size70 lg:pl-8 lg:w-[580px] lg:text-left ",
                                        descriptionStyle: "description text-xl mt-2 xl:text-size26 lg:px-8 lg:w-[540px] lg:text-left",
                                    }),
                                }),
                                (0, c.jsx)(b, { className: s }),
                                (0, c.jsx)(rt, {
                                    state: i,
                                    start: "translateY(20px)",
                                    end: "translateY(0px)",
                                    className: "flex lg:flex-col lg:items-center gap-3 sm:gap-16 w-[200px] lg:w-[270px] m-auto lg:sm:m-[initial]",
                                    children: (0, c.jsx)(k, { className: "roundButtonClass bg-pageOrange shadow-glowRed", src: Q, href: "https://shop.bkgames.xyz/", linkTxt: "Coming Soon" }),
                                }),
                            ],
                        }),
                    ],
                });
            }
            var Z = r(7283),
                J = r(3359),
                ee = { src: "./_next/static/media/arrowGrey.d576127a.svg", height: 16, width: 24 },
                te = r(131);
            function re(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
                return n;
            }
            function ne(e, t) {
                return (
                    (function (e) {
                        if (Array.isArray(e)) return e;
                    })(e) ||
                    (function (e, t) {
                        var r = null == e ? null : ("undefined" !== typeof Symbol && e[Symbol.iterator]) || e["@@iterator"];
                        if (null != r) {
                            var n,
                                l,
                                a = [],
                                i = !0,
                                o = !1;
                            try {
                                for (r = r.call(e); !(i = (n = r.next()).done) && (a.push(n.value), !t || a.length !== t); i = !0);
                            } catch (s) {
                                (o = !0), (l = s);
                            } finally {
                                try {
                                    i || null == r.return || r.return();
                                } finally {
                                    if (o) throw l;
                                }
                            }
                            return a;
                        }
                    })(e, t) ||
                    (function (e, t) {
                        if (!e) return;
                        if ("string" === typeof e) return re(e, t);
                        var r = Object.prototype.toString.call(e).slice(8, -1);
                        "Object" === r && e.constructor && (r = e.constructor.name);
                        if ("Map" === r || "Set" === r) return Array.from(r);
                        if ("Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return re(e, t);
                    })(e, t) ||
                    (function () {
                        throw new TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
                    })()
                );
            }
            function le() {
                var e,
                    t,
                    r =
                        ((e = [
                            "\n    query BigNumber {\n        fieldBigBumbers {\n            data {\n                attributes {\n                    items {\n                        title\n                        description\n                    }\n                }\n            }\n        }\n    }\n",
                        ]),
                        t || (t = e.slice(0)),
                        Object.freeze(Object.defineProperties(e, { raw: { value: Object.freeze(t) } })));
                return (
                    (le = function () {
                        return r;
                    }),
                    r
                );
            }
            var ae = {
                    fieldBigBumbers: {
                        data: [
                            {
                                attributes: {
                                    items: [
                                        { title: "5,000+", description: "peak concurrent players" },
                                        { title: "2 million", description: "unique game sessions" },
                                        { title: "3,000+", description: "daily active users" },
                                    ],
                                },
                            },
                        ],
                    },
                },
                ie = (0, Z.Ps)(le());
            function oe() {
                var e = (0, n.useState)(ae),
                    t = e[0],
                    r = e[1],
                    l = ne((0, J.t)(ie), 2),
                    a = l[0],
                    i = l[1],
                    o = i.called,
                    s = i.data,
                    f = (0, te.YD)({ triggerOnce: !0, threshold: 0.65 }),
                    d = f.ref,
                    g = f.inView;
                return (
                    (0, n.useEffect)(
                        function () {
                            g && a();
                        },
                        [g, a]
                    ),
                    (0, n.useEffect)(
                        function () {
                            s && s.fieldBigBumbers && r(s);
                        },
                        [o, s]
                    ),
                    (0, c.jsxs)("div", {
                        className: "py-40 bg-screenTwoBg lg:bg-screenTwoBgLg bg-no-repeat bg-cover transform px-4",
                        children: [
                            (0, c.jsx)(A, {
                                state: g,
                                directionStart: "translateX(30px)",
                                directionEnd: "translateX(0px)",
                                className: "leading-6 relative pt-7",
                                title: "Game Status",
                                titleStyle: "title text-size34 lg:text-size50",
                                descriptionStyle: "description lg:text-size22 mt-2 lg:mt-4",
                            }),
                            (0, c.jsxs)("div", {
                                className: "pt-14 w-full pb-10 flex flex-col lg:flex-row md:justify-center items-center lg:gap-4 xl:gap-8",
                                children: [
                                    (0, c.jsx)(A, {
                                        state: g,
                                        directionStart: "translateY(30px)",
                                        directionEnd: "translateY(0px)",
                                        className: "infoButton bg-pagePink shadow-glowPink rounded-t-[40px] lg:rounded-[40px]",
                                        title: "5,000+",
                                        description: t && t.fieldBigBumbers.data[0].attributes.items[0].description,
                                        titleStyle: "text-center font-bold text-size50 text-white relativePushTop2",
                                        descriptionStyle: "text-center font-bold text-xl text-white mt-4 relativePushTop1",
                                    }),
                                    (0, c.jsx)("div", { className: "hidden xl:block", children: (0, c.jsx)(u.default, { src: ee, alt: "arrowGrey" }) }),
                                    (0, c.jsx)("span", { ref: d }),
                                    (0, c.jsx)(A, {
                                        state: g,
                                        directionStart: "translateY(30px)",
                                        directionEnd: "translateY(0px)",
                                        className: "infoButton bg-pageBlue shadow-glowBlue lg:rounded-[40px]",
                                        title: "2 million",
                                        description: t && t.fieldBigBumbers.data[0].attributes.items[1].description,
                                        titleStyle: "text-center font-bold text-size50 text-white relative relativePushTop2",
                                        descriptionStyle: "text-center font-bold text-xl text-white mt-4 relativePushTop1",
                                    }),
                                    (0, c.jsx)("div", { className: "hidden xl:block", children: (0, c.jsx)(u.default, { src: ee, alt: "arrowGrey" }) }),
                                    (0, c.jsx)(A, {
                                        state: g,
                                        directionStart: "translateY(30px)",
                                        directionEnd: "translateY(0px)",
                                        className: "infoButton bg-pageOrange shadow-glowOrange rounded-b-[40px] lg:rounded-[40px]",
                                        title: "3,000+",
                                        description: t && t.fieldBigBumbers.data[0].attributes.items[2].description,
                                        titleStyle: "text-center font-bold text-size50 text-white relativePushTop2",
                                        descriptionStyle: "text-center font-bold text-xl text-white mt-4 relativePushTop1",
                                    }),
                                ],
                            }),
                        ],
                    })
                );
            }
            function se() {
                var e = (0, te.YD)({ triggerOnce: !0, threshold: 0.5 }),
                    t = e.ref,
                    r = e.inView;
                return (0, c.jsx)("div", {
                    className: "w-full relative flex justify-center pb-[250px] pt-[50px]",
                    ref: t,
                    children: (0, c.jsxs)("div", {
                        className: "w-full",
                        children: [
                            (0, c.jsx)(A, {
                                state: r,
                                directionStart: "translateY(15px)",
                                directionEnd: "translateY(0px)",
                                className: "leading-6 relative pt-14",
                                title: "Our Games",
                                description: "Check out our ever expanding library of games here.",
                                titleStyle: "title text-size50",
                                descriptionStyle: "description text-xl mt-2",
                            }),
                            (0, c.jsx)("div", { className: "", children: (0, c.jsx)(U, {}) }),
                        ],
                    }),
                });
            }
            var ce = r(1163),
                ue = { src: "/_next/static/media/bigGames.66f7ea84.svg", height: 50, width: 68 },
                fe = { src: "/_next/static/media/lupe.f31b6432.svg", height: 16, width: 16 };
            var de = (0, p.Pi)(function (e) {
                    var t = e.navbar,
                        r = e.imageW,
                        l = e.imageH,
                        i = e.sidebar,
                        o = e.leftIcon,
                        s = function (e) {
                            var t = e.currentTarget;
                            if ((t.dataset.index && x(t.dataset.index), "/" === d.pathname)) {
                                var r = document.querySelector("#".concat(t.dataset.id));
                                ("home" !== t.dataset.id && "ourgames" !== t.dataset.id) || r.scrollIntoView({ behavior: "smooth" });
                            } else d.push("/");
                        },
                        f = (0, m.oR)().state,
                        d = (0, ce.useRouter)(),
                        g = (0, n.useState)("0"),
                        p = g[0],
                        x = g[1];
                    (0, n.useEffect)(
                        function () {
                            d.pathname.includes("/post") && x("3");
                        },
                        [d.pathname]
                    );
                    var h = a()({ "w-full px-4 fixed top-0 z-[99999] bg-pageBg/70 backdrop-blur-md": t, "w-full": i }),
                        b = a()({ "relative -left-5 md:left-0 transform-gpu md:scale-135 md:translate-y-1 md:w-[92px] md:flex md:justify-center": !0 }),
                        y = a()({ "flex py-3 md:py-10 items-center": !0, "px-4 bg-pageBg/90": i }),
                        v = (0, P.useSpring)({ config: P.config.default, transform: f.toggleSearch ? "translateX(-1%)" : "translateX(-120%)" });
                    return (0, c.jsx)(c.Fragment, {
                        children: (0, c.jsxs)("nav", {
                            className: h,
                            children: [
                                (0, c.jsxs)("div", {
                                    className: y,
                                    children: [
                                        (0, c.jsx)("div", {
                                            onClick: function () {
                                                return f.toogleHamburger();
                                            },
                                            className: "rounded-full shrink-0 h-[40px] w-[40px] bg-white flex justify-center items-center shadow-md md:hidden",
                                            children: (0, c.jsx)(u.default, { src: o, alt: "left_icon", width: r, height: l }),
                                        }),
                                        (0, c.jsxs)("div", {
                                            className: "w-full flex items-center justify-center md:gap-8 lg:gap-20",
                                            children: [
                                                (0, c.jsx)("p", { "data-index": "0", "data-id": "home", className: "0" !== p ? "navButton" : "navButtonSelected", onClick: s, children: "HOME" }),
                                                (0, c.jsx)("p", { "data-index": "1", "data-id": "ourgames", className: "1" !== p ? "navButton" : "navButtonSelected", onClick: s, children: "OUR GAMES" }),
                                                (0, c.jsx)("div", { className: b, children: (0, c.jsx)(u.default, { src: ue, alt: "BIG_GAMES_LOGO" }) }),
                                                (0, c.jsx)(w.default, {
                                                    href: "https://shop.bkgames.xyz/",
                                                    children: (0, c.jsx)("a", {
                                                        rel: "noopener noreferrer",
                                                        children: (0, c.jsx)("p", { "data-index": "2", "data-id": "sickmerch", className: "2" !== p ? "navButton" : "navButtonSelected", onClick: s, children: "SICK MERCH" }),
                                                    }),
                                                }),
                                                (0, c.jsx)(w.default, {
                                                    href: "/post",
                                                    children: (0, c.jsx)("a", { children: (0, c.jsx)("p", { "data-index": "3", "data-id": "devblogs", className: "3" !== p ? "navButton" : "navButtonSelected", children: "DEV BLOGS" }) }),
                                                }),
                                            ],
                                        }),
                                    ],
                                }),
                                i ? (0, c.jsx)("hr", {}) : null,
                                (0, c.jsx)(P.a.div, {
                                    style: v,
                                    className: "absolute top-3 w-[95%] bg-white rounded-full overflow-hidden px-2 lg:hidden transform-gpu translate-y-[-50%]",
                                    children: (0, c.jsxs)("label", {
                                        className: "flex items-center",
                                        children: [
                                            (0, c.jsx)("div", { className: "relative top-1 ml-2", children: (0, c.jsx)(u.default, { src: fe, alt: "lupe_icon", width: 20, height: 20 }) }),
                                            (0, c.jsx)("input", { className: "appearance-none font-bold px-2 rounded-full outline-none py-4 w-full caret-pageBlue", type: "text", name: "search", placeholder: "Search Blogs" }),
                                            (0, c.jsx)("div", {
                                                className: "relative bg-timeDone/10 rounded-full p-2",
                                                onClick: function () {
                                                    return f.toggleSearchField();
                                                },
                                                children: (0, c.jsx)(Je, { className: "w-[14px] h-[14px] fill-[#555555]" }),
                                            }),
                                        ],
                                    }),
                                }),
                            ],
                        }),
                    });
                }),
                ge = { src: "/_next/static/media/closingX.d4f7fc93.svg", height: 14, width: 14 };
            var me = (0, p.Pi)(function () {
                    var e = function (e) {
                            var n = e.currentTarget;
                            "/" === r.pathname ? ("home" !== n.dataset.id && "ourgames" !== n.dataset.id) || document.querySelector("#".concat(n.dataset.id)).scrollIntoView({ behavior: "smooth" }) : r.push("/");
                            t.toogleHamburger();
                        },
                        t = (0, m.oR)().state,
                        r = (0, ce.useRouter)(),
                        n = a()({
                            "bg-pageBg/70 min-h-screen flex flex-col justify-start backdrop-blur-md": !0,
                            "w-full fixed top-0 -translate-x-full z-20 defaultTransition": !t.hamburgerOpen,
                            "w-full fixed top-0 -translate-x-0 z-20 defaultTransition": t.hamburgerOpen,
                        });
                    return (0,
                    c.jsxs)("div", { className: n, children: [(0, c.jsx)(de, { imageH: 14, imageW: 18, sidebar: !0, leftIcon: ge }), (0, c.jsxs)("div", { className: "pageBg/90 px-4 flex flex-col gap-5 mt-6", children: [(0, c.jsx)("div", { "data-id": "home", onClick: e, className: "px-4 rounded-full m-auto shadow-sm text-center text-xl text-pageBlack font-bold bg-white w-full max-w-[380px] py-5", children: "Home" }), (0, c.jsx)("div", { "data-id": "ourgames", onClick: e, className: "px-4 rounded-full m-auto shadow-sm text-center text-xl text-pageBlack font-bold bg-white w-full max-w-[380px] py-5", children: "Our Games" }), (0, c.jsx)(w.default, { href: "https://shop.bkgames.xyz/", passHref: !0, children: (0, c.jsx)("div", { className: "px-4 rounded-full m-auto shadow-sm text-center text-xl text-pageBlack font-bold bg-white w-full max-w-[380px] py-5", children: (0, c.jsx)("a", { target: "_blank", rel: "noopener noreferrer", children: "Sick Merch" }) }) }), (0, c.jsx)(w.default, { href: "/post", passHref: !0, children: (0, c.jsx)("div", { onClick: e, className: "px-4 rounded-full m-auto shadow-sm text-center text-xl text-pageBlack font-bold bg-white w-full max-w-[380px] py-5", children: (0, c.jsx)("a", { children: "Dev Blogs" }) }) })] }), (0, c.jsx)(z, { className: "w-full h-full px-4 gap-4 flex justify-center mt-auto mb-24" })] });
                }),
                pe = { src: "/_next/static/media/hamburger.48056bf1.svg", height: 12, width: 18 };
            function xe(e) {
                var t = e.blog,
                    r = void 0 !== t && t;
                return (0, c.jsxs)(c.Fragment, { children: [(0, c.jsx)(me, {}), (0, c.jsx)(de, { imageW: 17, imageH: 12, blog: r, navbar: !0, leftIcon: pe })] });
            }
            var he = [
                { name: "All Posts", tag: "", link: "/post" },
                { name: "Pet Simulator Z!", tag: "Pet Simulator Z!", link: "/post/category/pet-simulator-x" },
                { name: "BIG Paintball!", tag: "BIG Paintball!", link: "/post/category/big-paintball" },
                { name: "Pet Simulator 2!", tag: "Pet Simulator 2!", link: "/post/category/pet-simulator-2" },
                { name: "Build & Survive!", tag: "Build & Survive!", link: "/post/category/build-and-survive" },
                { name: "Pet Simulator 1!", tag: "Pet Simulator 1!", link: "/post/category/pet-simulator-1" },
                { name: "Other", tag: "Other", link: "/post/category/other" },
            ];
            function be(e) {
                var t = e.withoutBlogNavigation,
                    r = (0, ce.useRouter)(),
                    l = (0, n.useState)(0),
                    i = (l[0], l[1]),
                    o = (0, n.useRef)(!1),
                    s = function (e) {
                        var t = e.currentTarget;
                        t.dataset.id && i(Number(t.dataset.id));
                    };
                (0, n.useEffect)(function () {
                    o.current = !0;
                }, []);
                var u = a()({ "pt-2 lg:row-start-1 lg:row-end-2 lg:col-start-1 lg:col-end-4": !t, hidden: t });
                return (0, c.jsxs)("div", {
                    className: u,
                    children: [
                        (0, c.jsx)("section", { className: "flex justify-between items-center px-4 mb-4", children: (0, c.jsx)("h2", { className: "hidden md:block font-bold text-size50 m-auto", children: "Developer Blogs" }) }),
                        (0, c.jsx)("ul", {
                            className: "flex group gap-6 lg:gap-3 w-full overflow-x-scroll scrollbar scrollbar-none scrollbar-thumb-pageOrange scrollbar-no-width px-2 scroll-smooth md:overflow-x-auto lg:overflow-x-visible",
                            children: he.map(function (e, t) {
                                return e.link === r.pathname
                                    ? (0, c.jsx)(
                                          w.default,
                                          {
                                              href: e.link,
                                              passHref: !0,
                                              children: (0, c.jsx)("a", {
                                                  children: (0, c.jsx)(je, {
                                                      "data-id": t,
                                                      searchOnClick: s,
                                                      value: e.name,
                                                      className:
                                                          "font-bold whitespace-nowrap cursor-pointer shrink-0 mb-1 px-3 py-2 tracking-tight text-pageOrange relative after:content-[''] after:absolute after:-bottom-1 after:bg-pageOrange after:defaultTransition after:w-full after:left-0 after:h-1",
                                                  }),
                                              }),
                                          },
                                          e.name
                                      )
                                    : (0, c.jsx)(
                                          w.default,
                                          {
                                              href: e.link,
                                              passHref: !0,
                                              children: (0, c.jsx)("a", {
                                                  children: (0, c.jsx)(je, {
                                                      "data-id": t,
                                                      searchOnClick: s,
                                                      value: e.name,
                                                      className:
                                                          "font-bold whitespace-nowrap cursor-pointer shrink-0 mb-1 px-3 py-2 tracking-tight hover:text-pageOrange text-timeDone relative after:content-[''] after:absolute after:-bottom-1 after:bg-pageOrange after:w-0 after:defaultTransition lg:after:hover:w-full after:left-0 after:h-1",
                                                  }),
                                              }),
                                          },
                                          e.name
                                      );
                            }),
                        }),
                        (0, c.jsx)("hr", { className: "border-2 border-black/10 relative -top-1" }),
                    ],
                });
            }
            function ye(e, t, r) {
                return t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : (e[t] = r), e;
            }
            function ve(e, t) {
                if (null == e) return {};
                var r,
                    n,
                    l = (function (e, t) {
                        if (null == e) return {};
                        var r,
                            n,
                            l = {},
                            a = Object.keys(e);
                        for (n = 0; n < a.length; n++) (r = a[n]), t.indexOf(r) >= 0 || (l[r] = e[r]);
                        return l;
                    })(e, t);
                if (Object.getOwnPropertySymbols) {
                    var a = Object.getOwnPropertySymbols(e);
                    for (n = 0; n < a.length; n++) (r = a[n]), t.indexOf(r) >= 0 || (Object.prototype.propertyIsEnumerable.call(e, r) && (l[r] = e[r]));
                }
                return l;
            }
            var je = (0, n.memo)(function (e) {
                var t = e.searchOnClick,
                    r = e.value,
                    l = ve(e, ["searchOnClick", "value"]);
                return (0, n.createElement)(
                    "li",
                    (function (e) {
                        for (var t = 1; t < arguments.length; t++) {
                            var r = null != arguments[t] ? arguments[t] : {},
                                n = Object.keys(r);
                            "function" === typeof Object.getOwnPropertySymbols &&
                                (n = n.concat(
                                    Object.getOwnPropertySymbols(r).filter(function (e) {
                                        return Object.getOwnPropertyDescriptor(r, e).enumerable;
                                    })
                                )),
                                n.forEach(function (t) {
                                    ye(e, t, r[t]);
                                });
                        }
                        return e;
                    })({ onClick: t }, l),
                    r
                );
            });
            function we(e, t, r) {
                return t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : (e[t] = r), e;
            }
            function Oe() {
                return (
                    (Oe =
                        Object.assign ||
                        function (e) {
                            for (var t = 1; t < arguments.length; t++) {
                                var r = arguments[t];
                                for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
                            }
                            return e;
                        }),
                    Oe.apply(this, arguments)
                );
            }
            var Se = [
                    { txt: "Merchandise", link: "https://shop.bkgames.xyz/" },
                    { txt: "Developer Blogs", link: "/post" },
                ],
                Ne = [
                    { txt: "Twitter", link: "https://twitter.com/BKOfficialTeam" },
                    { txt: "Discord", link: "https://discord.com/invite/bkgames" },
                    { txt: "YouTube", link: "https://www.youtube.com/@BKProsYT/featured" },
                    { txt: "Roblox", link: "https://www.roblox.com/games/11213263186/BK-Games-Hub" },
                ];
            function ke(e) {
                var t = Oe({}, e),
                    r = a()({ "flex flex-row gap-8 mt-12 px-4 lg:px-0 relative md:flex-row justify-evenly lg:w-full": !0 }),
                    l = (0, n.useState)(!0),
                    i = l[0],
                    o = l[1],
                    s = (0, n.useState)(!1),
                    u = s[0],
                    f = s[1];
                return (0, c.jsxs)(
                    "div",
                    (function (e) {
                        for (var t = 1; t < arguments.length; t++) {
                            var r = null != arguments[t] ? arguments[t] : {},
                                n = Object.keys(r);
                            "function" === typeof Object.getOwnPropertySymbols &&
                                (n = n.concat(
                                    Object.getOwnPropertySymbols(r).filter(function (e) {
                                        return Object.getOwnPropertyDescriptor(r, e).enumerable;
                                    })
                                )),
                                n.forEach(function (t) {
                                    we(e, t, r[t]);
                                });
                        }
                        return e;
                    })({ className: r }, t, {
                        children: [
                            (0, c.jsx)(Ie, {
                                boxOpener: function () {
                                    o(function (e) {
                                        return !e;
                                    }),
                                        u && f(!1);
                                },
                                isOpen: !0,
                                heightOpen: "h-[140px]",
                                boxTitle: "Site",
                                children: (0, c.jsx)(Te, { liStyle: "py-1 font-medium text-size18 text-timeDone", className: "", liArr: Se }),
                            }),
                            (0, c.jsx)(Ie, {
                                boxOpener: function () {
                                    f(function (e) {
                                        return !e;
                                    }),
                                        i && o(!1);
                                },
                                isOpen: !0,
                                heightOpen: "h-[140px]",
                                boxTitle: "Connect",
                                children: (0, c.jsx)(Te, { liStyle: "py-1 font-medium text-size18 text-timeDone", className: "", liArr: Ne }),
                            }),
                        ],
                    })
                );
            }
            function Pe(e, t, r) {
                return t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : (e[t] = r), e;
            }
            function Be(e, t) {
                if (null == e) return {};
                var r,
                    n,
                    l = (function (e, t) {
                        if (null == e) return {};
                        var r,
                            n,
                            l = {},
                            a = Object.keys(e);
                        for (n = 0; n < a.length; n++) (r = a[n]), t.indexOf(r) >= 0 || (l[r] = e[r]);
                        return l;
                    })(e, t);
                if (Object.getOwnPropertySymbols) {
                    var a = Object.getOwnPropertySymbols(e);
                    for (n = 0; n < a.length; n++) (r = a[n]), t.indexOf(r) >= 0 || (Object.prototype.propertyIsEnumerable.call(e, r) && (l[r] = e[r]));
                }
                return l;
            }
            function Ie(e) {
                var t,
                    r = e.boxTitle,
                    n = e.heightOpen,
                    l = e.isOpen,
                    i = e.boxOpener,
                    o = e.children,
                    s = e.childrenWrapperStyle,
                    f = Be(e, ["boxTitle", "heightOpen", "isOpen", "boxOpener", "children", "childrenWrapperStyle"]),
                    d = a()((Pe((t = { defaultTransition: !0, "h-0": !l }), "".concat(n), l), Pe(t, "".concat(s), s), t)),
                    g = a()({ "defaultTransition w-6 h-6 flex items-center justify-center hidden": !0, "rotate-0": !l, "rotate-45": l });
                return (0, c.jsxs)(
                    "div",
                    (function (e) {
                        for (var t = 1; t < arguments.length; t++) {
                            var r = null != arguments[t] ? arguments[t] : {},
                                n = Object.keys(r);
                            "function" === typeof Object.getOwnPropertySymbols &&
                                (n = n.concat(
                                    Object.getOwnPropertySymbols(r).filter(function (e) {
                                        return Object.getOwnPropertyDescriptor(r, e).enumerable;
                                    })
                                )),
                                n.forEach(function (t) {
                                    Pe(e, t, r[t]);
                                });
                        }
                        return e;
                    })({ className: "overflow-hidden" }, f, {
                        children: [
                            (0, c.jsxs)("div", {
                                className: "flex justify-between items-center",
                                children: [(0, c.jsx)("h2", { className: "footerTitle", onClick: i, children: r }), (0, c.jsx)("div", { className: g, children: (0, c.jsx)(u.default, { src: R, alt: "plus_svg" }) })],
                            }),
                            (0, c.jsx)("div", { className: d, children: o }),
                        ],
                    })
                );
            }
            function Ae(e, t, r) {
                return t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : (e[t] = r), e;
            }
            function Ee(e, t) {
                if (null == e) return {};
                var r,
                    n,
                    l = (function (e, t) {
                        if (null == e) return {};
                        var r,
                            n,
                            l = {},
                            a = Object.keys(e);
                        for (n = 0; n < a.length; n++) (r = a[n]), t.indexOf(r) >= 0 || (l[r] = e[r]);
                        return l;
                    })(e, t);
                if (Object.getOwnPropertySymbols) {
                    var a = Object.getOwnPropertySymbols(e);
                    for (n = 0; n < a.length; n++) (r = a[n]), t.indexOf(r) >= 0 || (Object.prototype.propertyIsEnumerable.call(e, r) && (l[r] = e[r]));
                }
                return l;
            }
            function Te(e) {
                var t = e.liArr,
                    r = e.liStyle,
                    n = Ee(e, ["liArr", "liStyle"]);
                return (0, c.jsx)(
                    "ul",
                    (function (e) {
                        for (var t = 1; t < arguments.length; t++) {
                            var r = null != arguments[t] ? arguments[t] : {},
                                n = Object.keys(r);
                            "function" === typeof Object.getOwnPropertySymbols &&
                                (n = n.concat(
                                    Object.getOwnPropertySymbols(r).filter(function (e) {
                                        return Object.getOwnPropertyDescriptor(r, e).enumerable;
                                    })
                                )),
                                n.forEach(function (t) {
                                    Ae(e, t, r[t]);
                                });
                        }
                        return e;
                    })({}, n, {
                        children: t.map(function (e) {
                            return (0, c.jsx)("li", { className: r, children: (0, c.jsx)(w.default, { href: e.link, passHref: !0, children: (0, c.jsx)("a", { target: "_blank", rel: "noopener noreferrer", children: e.txt }) }) }, e.txt);
                        }),
                    })
                );
            }
            function De() {
                return (0, c.jsx)("div", {
                    className: "mb-20 lg:mb-0 w-full lg:flex lg:w-full lg:mt-12 px-4 lg:pl-4",
                    children: (0, c.jsxs)("div", {
                        className: "flex flex-col",
                        children: [
                            (0, c.jsx)("div", { className: "flex justify-center lg:justify-start py-3 lg:py-0", children: (0, c.jsx)(u.default, { src: ue, alt: "logo" }) }),
                            (0, c.jsx)("p", { className: "font-medium text-timeDone lg:mt-auto text-center lg:text-left", children: "Copyright \xa9 2022 BK Games." }),
                            (0, c.jsx)("p", { className: "font-medium text-timeDone text-center lg:text-left", children: "All rights reserved." }),
                        ],
                    }),
                });
            }
            var Me = (0, n.memo)(function (e) {
                    var t = e.blogHeader,
                        r = e.ratioImg,
                        n = e.headerTitle,
                        l = e.headerDescription,
                        i = e.linkText,
                        o = e.dummy,
                        u = void 0 !== o && o,
                        f = e.linkHref,
                        d = e.withInView,
                        g = e.frontpage,
                        m = e.blogMain,
                        p = e.blogItem,
                        x = e.blogImgSrc,
                        h = e.withLink,
                        b = void 0 === h || h,
                        y = e.date,
                        v = (0, te.YD)({ threshold: 0.4 }),
                        j = v.ref,
                        w = v.inView,
                        O = a()({
                            "font-Flow": u,
                            "bg-white/80 py-10 xl:py-40 flex justify-center": g,
                            "lg:py-10 max-w-[450px] lg:max-w-none m-auto flex justify-start mb-4 cursor-pointer": m,
                            "m-auto mb-4 lg:mb-0 lg:m-[initial] bg-white h-full self-start lg:bg-transparent hover:bg-white hover:shadow-md cursor-pointer defaultTransition max-w-[480px] rounded-blog pt-4 pb-5 px-1": p,
                        }),
                        S = a()({ "font-bold lg:hidden mt-12 mb-6 text-center text-pageOrange": !p, hidden: p }),
                        N = a()({ "font-medium hidden lg:block text-center xl:text-left text-pageOrange": !p, hidden: p }),
                        P = a()({ "flex justify-center lg:mt-4 xl:justify-start transform relative -translate-y-9 lg:translate-y-0": !p, hidden: p }),
                        B = a()({ "font-Flow": u, "title text-size34 xl:text-size50 xl:my-4 xl:text-left": !p, "title text-size34 xl:text-size50 xl:my-4 text-left leading-none": p }),
                        I = a()({ "px-4 flex flex-col lg:flex-row gap-8 xl:gap-14 lg:max-w-7xl": g || m, "px-4 flex flex-col gap-8 xl:gap-14 lg:max-w-7xl": p }),
                        E = a()({ "font-Flow": u, "description xl:text-left text-lg mt-2 leading-6": !p, "description text-sm text-left text-lg mt-2 leading-4 min-h-[50px] h-full": p }),
                        T = a()({ "absolute -top-1 z-[0] w-[110%] h-[100px] blur-sm bg-white/90 to-transparent lg:hidden": g, "absolute top-5 z-[0] w-[110%] h-[40px] blur-sm bg-heroBannerBG to-transparent lg:hidden": m });
                    return (0,
                    c.jsx)("div", { className: O, children: (0, c.jsxs)("div", { className: I, children: [(0, c.jsxs)("div", { className: "sm:max-w-lg xl:max-w-xl m-auto", children: [(0, c.jsx)("p", { className: S, children: t }), (0, c.jsx)($, { frontpage: g, blogMain: m, blogItem: p, blogImgSrc: x, ratioImg: r })] }), (0, c.jsxs)("div", { className: "sm:max-w-lg m-auto", ref: d ? j : null, children: [(0, c.jsx)("p", { className: N, children: t }), (0, c.jsx)(s, { className: "dateItem", children: y }), (0, c.jsx)(A, { state: !d || w, directionStart: "translateX(30px)", directionEnd: "translateX(0px)", className: "leading-12 relative", title: "Pet Simulator Z - Halloween Update", description: "Happy halloween! The Halloween Update is here along with a ton of other changes and additions!", titleStyle: B, descriptionStyle: E }), (0, c.jsxs)("div", { className: P, children: [(0, c.jsx)("div", { className: T }), (0, c.jsx)(k, { className: "roundButtonClass bg-pageBlue shadow-glowBlue flex flex-row-reverse", src: W, href: f, linkTxt: i, withLink: b })] })] })] }) });
                }),
                Ge = {
                    src: "petsimcat.png",
                    height: 2048,
                    width: 2048,
                    blurDataURL:
                        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAQlBMVEVMaXGZpbuDk7OQnbUzPVJ8jam5zOybprONmrG3xd5wf5xjcY94hqF+iZ4uO1EvO1KXpcCAkK6TpMKqssFNWW1LVmv5v/uMAAAAEXRSTlMA/eP+Qvme/GAsQ2D+EbmzOM4CicMAAAAJcEhZcwAALiMAAC4jAXilP3YAAAA3SURBVAiZZcGHEcAgEASxJT7Zc2D336oLQIJbLVAqkHeMO8P0Skl+0uQkp0Y/FoKdznptDPueHybTAbtI581lAAAAAElFTkSuQmCC",
                };
            function ze() {
                var e = (0, te.YD)({ threshold: 0.5 }),
                    t = e.ref,
                    r = e.inView;
                return (0, c.jsx)("div", {
                    className: "w-full px-4 absolute transform-gpu -translate-y-[170px] lg:-translate-y-[200px]",
                    ref: t,
                    children: (0, c.jsxs)("div", {
                        className: "bg-white m-auto overflow-hidden shadow-joinCommunity mt-12 py-12 lg:max-w-7xl rounded-[50px] lg:max-h-[324px] lg:flex lg:items-center lg:h-full",
                        children: [
                            (0, c.jsxs)("div", {
                                className: "lg:basis-3/5",
                                children: [
                                    (0, c.jsx)(A, {
                                        state: r,
                                        directionStart: "translateY(30px)",
                                        directionEnd: "translateY(0px)",
                                        className: "flex flex-col-reverse items-center lg:items-start lg:pl-spacing60 leading-6 lg:gap-6",
                                        title: "Join our community!",
                                        description: "Get the latest updates and more.",
                                        titleStyle: "text-pageBlack font-bold text-size34 lg:text-size50 xl:hidden",
                                        descriptionStyle: "description lg:text-2xl ",
                                        children: (0, c.jsx)("h2", { className: "text-pageBlack font-bold text-size34 lg:text-size50 hidden xl:block", children: "Join our community today!" }),
                                    }),
                                    (0, c.jsx)(z, { className: "flex justify-center lg:justify-start lg:pl-spacing60 px-4 gap-3 mt-8 lg:mt-10" }),
                                ],
                            }),
                            (0, c.jsx)("div", {
                                className: "lg:basis-[30%] hidden lg:block relative top-4 xl:-top-6",
                                children: (0, c.jsx)(u.default, { src: Ge, alt: "", layout: "responsive", objectFit: "contain", objectPosition: "50% 100%", width: "50%", height: "50%" }),
                            }),
                        ],
                    }),
                });
            }
            function Re(e) {
                var t = e.children,
                    r = e.withoutBlogNavigation,
                    n = e.centeredFooterXL,
                    l = a()({ "relative bg-heroBannerBG mt-[80px] md:mt-[130px] px-4": !0, "lg:grid lg:grid-cols-desktop lg:grid-rows-default lg:justify-items-center": !0 }),
                    i = a()({ "flex flex-col justify-between mt-[3.25rem] lg:mt-[1.5rem] lg:pb-[3.25rem] px-4": !0 }),
                    o = a()({ "lg:max-w-7xl m-auto w-full lg:flex lg:flex-row-reverse": !0, "xl:m-auto": n });
                return (0, c.jsxs)(c.Fragment, {
                    children: [
                        (0, c.jsx)(xe, { blog: !0 }),
                        (0, c.jsxs)("main", { className: l, children: [(0, c.jsx)(be, { withoutBlogNavigation: r }), t] }),
                        (0, c.jsx)("footer", { className: i, children: (0, c.jsxs)("div", { className: o, children: [(0, c.jsx)(ke, {}), (0, c.jsx)(De, {})] }) }),
                    ],
                });
            }
            var _e = r(9008);
            function Ce() {
                return (0, c.jsxs)("div", {
                    children: [
                        (0, c.jsxs)(_e.default, {
                            children: [
                                (0, c.jsx)("title", { children: "DEV BLOGS | BK Games" }),
                                (0, c.jsx)("meta", { name: "viewport", content: "width=device-width, initial-scale=1" }),
                                (0, c.jsx)("meta", { property: "og:title", content: "DEV BLOGS | BK Games" }),
                                (0, c.jsx)("meta", { property: "og:description", content: "Development blogs and updates for BK Games and our projects!" }),
                                (0, c.jsx)("meta", { property: "og:image", content: "https://bigblog-storage.s3.us-east-1.amazonaws.com/Logo.png" }),
                            ],
                        }),
                        (0, c.jsx)(Re, {
                            children: (0, c.jsx)("div", { className: "col-start-2 col-end-3 lg:max-w-8xl h-96 flex", children: (0, c.jsx)("h2", { className: "hidden md:block font-bold text-size50 m-auto", children: "None" }) }),
                        }),
                    ],
                });
            }
            function Ye() {
                return (0, c.jsxs)("div", {
                    className: "bg-pageBg/90 overflow-x-hidden",
                    children: [
                        (0, c.jsx)(_e.default, { children: (0, c.jsx)("title", { children: "DEV BLOGS | BK Games" }) }),
                        (0, c.jsx)(Re, {
                            withoutBlogNavigation: !0,
                            centeredFooterXL: !0,
                            children: (0, c.jsx)("div", {
                                className: "col-start-2 col-end-3 lg:max-w-8xl h-[70vh] flex",
                                children: (0, c.jsx)("h2", { className: "hidden md:block font-bold text-size50 m-auto", children: "Nothing yet here" }),
                            }),
                        }),
                    ],
                });
            }
            var He = r(7484),
                Le = r.n(He),
                We = r(4710);
            function Ve(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
                return n;
            }
            function Fe(e, t) {
                return (
                    (function (e) {
                        if (Array.isArray(e)) return e;
                    })(e) ||
                    (function (e, t) {
                        var r = null == e ? null : ("undefined" !== typeof Symbol && e[Symbol.iterator]) || e["@@iterator"];
                        if (null != r) {
                            var n,
                                l,
                                a = [],
                                i = !0,
                                o = !1;
                            try {
                                for (r = r.call(e); !(i = (n = r.next()).done) && (a.push(n.value), !t || a.length !== t); i = !0);
                            } catch (s) {
                                (o = !0), (l = s);
                            } finally {
                                try {
                                    i || null == r.return || r.return();
                                } finally {
                                    if (o) throw l;
                                }
                            }
                            return a;
                        }
                    })(e, t) ||
                    Ue(e, t) ||
                    (function () {
                        throw new TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
                    })()
                );
            }
            function Xe(e) {
                return (
                    (function (e) {
                        if (Array.isArray(e)) return Ve(e);
                    })(e) ||
                    (function (e) {
                        if (("undefined" !== typeof Symbol && null != e[Symbol.iterator]) || null != e["@@iterator"]) return Array.from(e);
                    })(e) ||
                    Ue(e) ||
                    (function () {
                        throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
                    })()
                );
            }
            function Ue(e, t) {
                if (e) {
                    if ("string" === typeof e) return Ve(e, t);
                    var r = Object.prototype.toString.call(e).slice(8, -1);
                    return "Object" === r && e.constructor && (r = e.constructor.name), "Map" === r || "Set" === r ? Array.from(r) : "Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r) ? Ve(e, t) : void 0;
                }
            }
            function qe() {
                var e,
                    t,
                    r =
                        ((e = [
                            '\n    query DevBlog($searchString: String!, $offset: Int!, $limit: Int!) {\n        devBlogs(\n            filters: { tag: { startsWith: $searchString } }\n            sort: "date:desc"\n            pagination: { start: $offset, limit: $limit }\n        ) {\n            data {\n                attributes {\n                    mainPageHeaderTitle\n                    title\n                    description\n                    date\n                    slug\n                    imgLink\n                    tag\n                }\n            }\n        }\n    }\n',
                        ]),
                        t || (t = e.slice(0)),
                        Object.freeze(Object.defineProperties(e, { raw: { value: Object.freeze(t) } })));
                return (
                    (qe = function () {
                        return r;
                    }),
                    r
                );
            }
            var $e = (0, Z.Ps)(qe());
            function Qe(e) {
                var t = e.dataProps,
                    r = e.fetchMoreQueryString,
                    l = (0, ce.useRouter)(),
                    a = (0, n.useRef)(1),
                    i = (0, n.useState)(!1),
                    o = i[0],
                    s = i[1],
                    u = (0, n.useRef)(!1),
                    f = Fe((0, J.t)($e, { variables: { searchString: "", offset: 0, limit: 10 } }), 2),
                    d = f[0],
                    g = f[1].data,
                    m = (0, n.useState)(t),
                    p = m[0],
                    x = m[1],
                    h = (0, n.useRef)(null),
                    b = (0, n.useRef)(10);
                return (
                    (0, n.useEffect)(
                        function () {
                            var e = (0, We.P)(function () {
                                h.current &&
                                    Math.floor(0.8 * h.current.offsetHeight) - Math.floor(window.scrollY) < 0 &&
                                    !o &&
                                    a.current > 0 &&
                                    ((u.current = !0),
                                    s(function (e) {
                                        return !e;
                                    }));
                            }, 500);
                            return (
                                window.addEventListener("scroll", e),
                                function () {
                                    return removeEventListener("scroll", e);
                                }
                            );
                        },
                        [l.pathname, o]
                    ),
                    (0, n.useEffect)(
                        function () {
                            o && (d({ variables: { searchString: r, offset: b.current, limit: 10 } }), (u.current = !0), (b.current += 10));
                        },
                        [o, r, d]
                    ),
                    (0, n.useEffect)(
                        function () {
                            g &&
                                ((a.current = g.devBlogs.data.length),
                                x(function (e) {
                                    return Xe(e).concat(Xe(g.devBlogs.data));
                                }));
                        },
                        [g]
                    ),
                    (0, c.jsx)(Re, {
                        children: (0, c.jsxs)("div", {
                            className: "lg:row-start-2 lg:row-end-3 lg:col-start-2 lg:col-end-3",
                            ref: h,
                            children: [
                                (0, c.jsx)(Me, {
                                    blogHeader: "''" == t[0].attributes.mainPageHeaderTitle ? "" : t[0].attributes.mainPageHeaderTitle,
                                    headerTitle: t[0].attributes.title,
                                    headerDescription: t[0].attributes.description,
                                    linkText: "Read More",
                                    linkHref: "/post/".concat(t[0].attributes.slug),
                                    blogImgSrc: "" == t[0].attributes.imgLink ? "https://bigblog-storage.s3.us-east-1.amazonaws.com/logo_mini_38802529e0-PhotoRoom.png" : t[0].attributes.imgLink,
                                    blogMain: !0,
                                    ratioImg: 0.75,
                                }),
                                (0, c.jsx)("div", {
                                    className: "lg:grid lg:grid-cols-3 xl:grid-cols-3 lg:gap-2 lg:gap-y-4 lg:max-w-8xl pb-5",
                                    children:
                                        p &&
                                        p.map(function (e, t) {
                                            return t > 0
                                                ? (0, c.jsx)(
                                                      w.default,
                                                      {
                                                          href: "/post/".concat(e.attributes.slug),
                                                          children: (0, c.jsx)("a", {
                                                              children: (0, c.jsx)(
                                                                  Me,
                                                                  {
                                                                      blogHeader: "",
                                                                      headerTitle: e.attributes.title,
                                                                      headerDescription: e.attributes.description,
                                                                      linkText: "",
                                                                      linkHref: "",
                                                                      withLink: !1,
                                                                      blogImgSrc: e.attributes.imgLink,
                                                                      blogItem: !0,
                                                                      date: Le()(e.attributes.date).format("MMMM DD, YYYY"),
                                                                      ratioImg: 0.6,
                                                                  },
                                                                  e.attributes.title
                                                              ),
                                                          }),
                                                      },
                                                      e.attributes.title + t
                                                  )
                                                : null;
                                        }),
                                }),
                            ],
                        }),
                    })
                );
            }
            function Ke(e, t, r) {
                return t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : (e[t] = r), e;
            }
            function Ze() {
                return (
                    (Ze =
                        Object.assign ||
                        function (e) {
                            for (var t = 1; t < arguments.length; t++) {
                                var r = arguments[t];
                                for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
                            }
                            return e;
                        }),
                    Ze.apply(this, arguments)
                );
            }
            function Je(e) {
                var t = Ze({}, e);
                return (0, c.jsx)(
                    "svg",
                    (function (e) {
                        for (var t = 1; t < arguments.length; t++) {
                            var r = null != arguments[t] ? arguments[t] : {},
                                n = Object.keys(r);
                            "function" === typeof Object.getOwnPropertySymbols &&
                                (n = n.concat(
                                    Object.getOwnPropertySymbols(r).filter(function (e) {
                                        return Object.getOwnPropertyDescriptor(r, e).enumerable;
                                    })
                                )),
                                n.forEach(function (t) {
                                    Ke(e, t, r[t]);
                                });
                        }
                        return e;
                    })({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 14 14" }, t, {
                        children: (0, c.jsx)("path", {
                            fillRule: "evenodd",
                            d:
                                "M2.05025.636033c-.39053-.390524-1.02369-.390524-1.414217 0-.390524.390527-.390524 1.023687 0 1.414217L5.58578 6.99999.636033 11.9497c-.390524.3906-.390524 1.0237 0 1.4143.390527.3905 1.023687.3905 1.414217 0l4.94974-4.94979L11.9497 13.364c.3906.3905 1.0237.3905 1.4143 0 .3905-.3906.3905-1.0237 0-1.4143L8.41421 6.99999 13.364 2.05025c.3905-.39053.3905-1.02369 0-1.414217-.3906-.390524-1.0237-.390524-1.4143 0L6.99999 5.58578 2.05025.636033Z",
                            clipRule: "evenodd",
                        }),
                    })
                );
            }
            function et(e, t, r) {
                return t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : (e[t] = r), e;
            }
            function tt(e, t) {
                if (null == e) return {};
                var r,
                    n,
                    l = (function (e, t) {
                        if (null == e) return {};
                        var r,
                            n,
                            l = {},
                            a = Object.keys(e);
                        for (n = 0; n < a.length; n++) (r = a[n]), t.indexOf(r) >= 0 || (l[r] = e[r]);
                        return l;
                    })(e, t);
                if (Object.getOwnPropertySymbols) {
                    var a = Object.getOwnPropertySymbols(e);
                    for (n = 0; n < a.length; n++) (r = a[n]), t.indexOf(r) >= 0 || (Object.prototype.propertyIsEnumerable.call(e, r) && (l[r] = e[r]));
                }
                return l;
            }
            function rt(e) {
                var t = e.state,
                    r = e.start,
                    n = e.end,
                    l = e.children,
                    a = tt(e, ["state", "start", "end", "children"]),
                    i = (0, P.useSpring)({ config: P.config.gentle, transform: t ? n : r, opacity: t ? 1 : 0, delay: 500 });
                return (0, c.jsx)(
                    P.a.div,
                    (function (e) {
                        for (var t = 1; t < arguments.length; t++) {
                            var r = null != arguments[t] ? arguments[t] : {},
                                n = Object.keys(r);
                            "function" === typeof Object.getOwnPropertySymbols &&
                                (n = n.concat(
                                    Object.getOwnPropertySymbols(r).filter(function (e) {
                                        return Object.getOwnPropertyDescriptor(r, e).enumerable;
                                    })
                                )),
                                n.forEach(function (t) {
                                    et(e, t, r[t]);
                                });
                        }
                        return e;
                    })({ style: i }, a, { children: l })
                );
            }
        },
        4710: function (e, t, r) {
            function n(e, t) {
                var r = !1;
                return function () {
                    r ||
                        ((r = !0),
                        setTimeout(function () {
                            e(), (r = !1);
                        }, t));
                };
            }
            r.d(t, {
                P: function () {
                    return n;
                },
            });
        },
    },
]);
