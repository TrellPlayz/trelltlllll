'use strict'

module.exports = {
  ROOT_URL: process.env.KEYMETRICS_NODE || 'https://root.keymetrics.io',
  PROTOCOL_VERSION: 2,
  PM2_VERSION: '2.0.0'
}
