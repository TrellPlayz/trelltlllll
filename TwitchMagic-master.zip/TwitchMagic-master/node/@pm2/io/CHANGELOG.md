
## 4.3.5

- refactor test suite
- add test against Node 14

## 4.3.4

- Do not send trace faster than 1000ms
- Instantly send traces to pm2.io (instead of ~60secs timeout)
- Allow metrics to be a boolean
- Add some examples/
- Track changes via CHANGELOG.md
