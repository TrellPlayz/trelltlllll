
module.exports = require('./src/InteractorClient.js')
