
# @pm2/pm2-version-check

This module is included in all major PM2 version to retrieve the latest PM2 version and gather some metrics about PM2 usage (PM2 version being runned)

## LICENSE

MIT
