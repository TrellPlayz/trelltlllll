export declare const BinaryOperators: string[];
export declare const AssignmentOperators: string[];
export declare const LogicalOperators: string[];
