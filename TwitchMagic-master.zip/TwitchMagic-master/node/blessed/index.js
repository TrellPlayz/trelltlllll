module.exports = require('./lib/blessed');
